const toggleBtn = document.querySelector(".close-btn");

toggleBtn.addEventListener("click", () => {
  toggleBtn.classList.toggle("open");
});
